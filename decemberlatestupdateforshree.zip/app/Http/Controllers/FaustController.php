<?php

namespace App\Http\Controllers;

class FaustController extends Controller
{
    public function index()
    {
        return view('faust');
    }
}
