<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete product',
        'body'    => 'Are you sure that you want to delete product ID :id with the name ":name"? This operation is irreversible.',
    ],

];
