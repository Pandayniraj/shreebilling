<?php

namespace App\Libraries\Pusher;

use Exception;

class PusherException extends Exception
{
}
