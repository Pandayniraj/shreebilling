<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete setting',
        'body'    => 'Are you sure that you want to delete the setting ":key"? This operation is irreversible.',
    ],

];
