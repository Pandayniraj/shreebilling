<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete user',
        'body'    => 'Are you sure that you want to delete user ID :id with the name ":full_name"? This operation is irreversible.',
    ],

];
