<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete document',
        'body'    => 'Are you sure that you want to delete document ID :id with the name ":name"? This operation is irreversible.',
    ],

];
