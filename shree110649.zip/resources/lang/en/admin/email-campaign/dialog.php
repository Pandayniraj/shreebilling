<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete email campaign',
        'body'    => 'Are you sure that you want to delete email campaign ID :id with the name ":name"? This operation is irreversible.',
    ],

];
