<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete client',
        'body'    => 'Are you sure that you want to delete client ID :id with the name ":name"? This operation is irreversible.',
    ],

];
