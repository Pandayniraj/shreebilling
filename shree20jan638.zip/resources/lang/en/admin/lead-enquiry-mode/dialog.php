<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete lead enquiry mode',
        'body'    => 'Are you sure that you want to delete lead enquiry mode ID :id with the name ":name"? This operation is irreversible.',
    ],

];
